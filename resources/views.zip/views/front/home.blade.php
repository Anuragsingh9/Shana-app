@extends('layouts.front')

@section('content')
<div id="loader">
    <img src="{{ publicAsset('css/images/loader.gif') }}" alt="Loader">
</div>
<div id="dataList" class="hidden">
    <div id="homeSlider" class="owl-carousel">
        {{--<div class="item">
            <div class="sliderBg" style="background: url('images/slider.jpg') no-repeat center;">
                <div class="container">
                    <div class="col-xs-6 sliderContent whiteText">
                        <div class="slideText">
                            <a class="e_learn_btn">E-Learning Solutions</a>
                            <h1>Complete Solutions For Your Education Needs</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="sliderBg" style="background: url('images/slider.jpg') no-repeat center;">
                <div class="container">
                    <div class="col-xs-6 sliderContent whiteText">
                        <div class="slideText">
                            <a class="e_learn_btn">E-Learning Solutions</a>
                            <h1>Complete Solutions For Your Education Needs</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>--}}
    </div>

   <div class="menulist_section">
    <div class="mainCoursesName">
        <div class="container">
            <ul id="course">
               {{--  <li><a href="#sec1">Maths</a></li>
                                                                            <li><a href="#sec2">English</a></li>
                                                                            <li><a href="#sec3">Perosnality Development</a></li>
                                                                            <li><a href="#sec4">Science</a></li>
                                                                            <li><a href="#sec5">Memory Enhancement</a></li>
                                                                            <li><a href="#sec6">Reasoning</a></li>
                                                                            <li><a href="#sec7">General Knowledge</a></li>
                                                                            <li><a href="#sec8">Motivational</a></li> --}}
            </ul>
        </div>
    </div>
    <!-- <div class="div_on_scroll clearfix"></div> -->
    <div class="clearfix courseNameList">
        <div class="container">
            
        </div>
    </div>
</div>

    <div class="app_section">
        <div class="container">
            <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1">
                <div class="col-xs-12 col-sm-6">
                    <img src="{{publicAsset('css/images/background-mobile.jpg')}}" class="img-responsive center-block">
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="app-details">
                        <div class="app-content">
                            <h2 class="title">PRACTICE, ANALYZE AND IMPROVE.<br/> NOW ON THE GO!</h2>
                            <p class="text">All of Testbook and more in the palm of your hands! Practice thousands of questions for free while having fun! Take free quizzes, mocktests and save all your important questions for revision. Read latest exam updates and articles from experts.</p>
                            <p class="text">Testbook App gives you the easiest and smoothest test-taking experience on your mobile device.</p>
                            <div class="get-apps-link">
                                <div class="input-state">
                                    <input id="mobileForAppLink" class="form-control" type="text" maxlength="10" placeholder="ENTER PHONE NUMBER">
                                    <button type="button" class="btn send-sms">GET LINK</button>
                                </div>
                            </div>
                            <div class="separator">
                                <span class="or-spacer">or</span>
                            </div>
                            <div class="play-store-url">
                                <a class="app-link" href="https://play.google.com/store/apps/details?id=com.shana&hl=en" target="_blank">
                                    <img class="img-responsive" alt="KC Pathshala App on Google Playstore" src="{{publicAsset('images/google-play-badge.png')}}">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{{-- dd(Auth::user()) --}}
@endsection

@push('script')
<script>

    var url="{{ url('') }}";
    gethomeSlider('front-home','GET',url);

    jQuery(document).ready(function() {
        // body...
        // home page Course Toggle Menu on mobile view
        if(window.innerWidth<=767){
          $(document).on('click','.list_course_name',function(){
            var current_menu = $(this).next();
            if(current_menu.is(':hidden')){
                $('.list_course_name').parent().find('.CourseSyllabus').slideUp();
                $(this).parent().find('.CourseSyllabus').slideDown();
            }else{
                $(this).parent().find('.CourseSyllabus').slideUp();
            }
          });
        }
    });
</script>
@endpush
