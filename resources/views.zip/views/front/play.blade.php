@extends('layouts.front')

@section('content')
<div id="loader">
    <img src="{{ publicAsset('css/images/loader.gif') }}" alt="Loader">
</div>
<div id="dataList" class="hidden">
<div class="banner_section clearfix">
    <div class="container page_title_section">
        <h1 class="page_title">Counting</h1>
    </div>
</div>

{{-- <div class="page_upper_text">
    <div class="container">
        <div class="row text-center">
            <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 col-md-offset-2">
                <h2>Want a personalized The World of Math experience?</h2>
                <p>Missions recommend what to learn next, help you remember what you’ve learned by mixing skills, and save your progress.</p>
            </div>
        </div>
    </div>
</div> --}}

<div class="page-topic-sec">
	<div class="container">
		<div class="row" id="document_list">
            <a id="media" data-fancybox data-type="iframe" data-src="" href="javascript:;" controls controlsList="nodownload">

            </a>
		</div>
	</div>
</div>
</div>

@push('script')
<script>
     path=window.location.href;
    var id=path.substr(path.lastIndexOf('/') + 1);
    data={document_id:id,user_id:'{{Auth::user()->id}}'};
    var res=apiAjaxCall('document-detail-web','POST',data)
     res.then(data => {
        if(data.data.audio_link!="")
        {
             $("#media").data('src',data.data.audio_link);
        }
        else if(data.data.video_link!="")
        {
            $("#media").data('src',data.data.video_link);
        }
        else
        {
            $("#media").data('src',data.data.text_link);
        }
        $(document).ajaxStop(function () {
                 $('#dataList').removeClass('hidden');
                 $('#loader').addClass('hidden');
                  $(document).ready(function() {
                     $("#media").fancybox({
                    afterLoad : function(instance, slide) {
                          
                    }}).trigger('click');

                     $('.fancybox-button--close').on('click',()=>{
                          history.go(-1)
                     })
                        console.log($('video[name="media"]'));
                     });
                  
    }); 

          
  </script>
@endpush
@endsection