@extends('layouts.master')
@section('content')
<div class="normalheader transition animated fadeIn small-header">
    <div class="hpanel">
        <div class="panel-body">
           

            
            <h2 class="font-light m-b-xs">
                User List
            </h2>
        </div>
    </div>
</div>
<div class="content animate-panel">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#student">Users</a></li>
           {{--         <li class=""><a data-toggle="tab" href="#teacher">Teacher</a></li>
                    <li class=""><a data-toggle="tab" href="#parents">Parents</a></li>
                    <li class=""><a data-toggle="tab" href="#competitor">Competitor</a></li>--}}
                </ul>
                <div class="tab-content">
                    <div id="student" class="tab-pane active">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table cellpadding="1" cellspacing="1" class="table">
                                    <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                       <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    @if(isset($staff['student']))
                                        @forelse($staff['student'] as $key => $val)

                                            <tr>
                                                <td>{{$key+1}}</td>
                                                <td>{{$val['name']}}</td>
                                                <td>{{$val['mobile']}}</td>

                                                <td>
                                                    <a href="{{url('view-user',$val['id'])}}"><button class="btn btn-xs btn-success">View</button></a>
                                                    <a class="delete-user" data-id="{{$val['id']}}"><button class="btn btn-xs btn-danger">Delete</button></a>
                                                </td>
                                            </tr>
                                        @empty
                                        @endforelse
                                    @endif
                                    </tbody>
                                </table>
                                {{ $staffs->links() }}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection