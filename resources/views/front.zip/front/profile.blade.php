@extends('layouts.front')

@section('content')
<div class="banner_section clearfix">
    <div class="container page_title_section">
        <h1 class="page_title">My Profile</h1>
    </div>
</div>

<div class="profile-section">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="col-sm-3">
					<img src="{{ cloudUrl(Auth::user()->photo) }}" class="center-block img-responsive" >
				</div>
				<div class="col-sm-9">
					<div class="profile-detail-row">
						<div class="name">Name</div>
						<div class="profile-name profile-det">{{Auth::user()->name}}</div>
					</div>
					<div class="profile-detail-row">
						<div class="name">Mobile</div>
						<div class="profile-email profile-det">{{Auth::user()->mobile}}</div>
					</div>
					<div class="profile-detail-row">
						<div class="name">Email</div>
						<div class="profile-password profile-det">@if(!empty(Auth::user()->email)){{Auth::user()->email}} @else {{'N/A'}}@endif</div>
					</div>
					<div class="profile-detail-row">
						<div class="name">Institiue</div>
						<div class="profile-password profile-det">@if(!empty(Auth::user()->institute)){{Auth::user()->institute}} @else {{'N/A'}}@endif</div>
					</div>

					<div class="profile-detail-row">
						<div class="name">Refferal Code</div>
						<div class="profile-refferal profile-det">{{Auth::user()->self_ref_code}}</div>
					</div>
					<div class="profile-detail-row">
						<div class="name">Active Plan</div>
						<div class="profile-plan profile-det">{{getUserPlan(Auth::user()->id)}}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<style type="text/css">
.profile-section{
	padding: 70px 0px;
}
.profile-detail-row {
    padding: 12px 0px;
    border-bottom: 1px solid #efefef;
    width: 60%;
}
.name {
    display: inline-block;
    width: 25%;
    /*float: left;*/
    font-weight: bold;
    /*border-right: 1px solid #ccc;*/
}
.profile-det{
	display: inline-block;
}
</style>


@endsection