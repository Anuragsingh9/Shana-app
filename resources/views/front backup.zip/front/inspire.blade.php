@extends('layouts.front')

@section('content')
<div style="background-color: #fff">
<img src="{{ publicAsset('css/images/coming.jpg') }}" class="img-responsive" style="margin:0 auto; width:800px" alt='Comming Soon'/>
</div>
@endsection